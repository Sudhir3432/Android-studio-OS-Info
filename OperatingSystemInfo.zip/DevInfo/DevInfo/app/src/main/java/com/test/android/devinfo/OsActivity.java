package com.test.android.devinfo;

import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;

public class OsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_os);
        TextView os_info_text=findViewById(R.id.os_info_text);
       
        os_info_text.append("Build release: " + Build.VERSION.RELEASE + "\n");
        os_info_text.append("Base OS: " + Build.VERSION.BASE_OS + "\n");
        os_info_text.append("CODE Name: " + Build.VERSION.CODENAME + "\n");
        os_info_text.append("Security patch: " + Build.VERSION.SECURITY_PATCH + "\n");
        os_info_text.append("Preview SDK: " + Build.VERSION.PREVIEW_SDK_INT + "\n");
        os_info_text.append("SDK/API version: " + Build.VERSION.SDK_INT + "\n");
        os_info_text.append("Display build: " + Build.DISPLAY + "\n");
        os_info_text.append("Finger print: " + Build.FINGERPRINT + "\n");
        os_info_text.append("Build ID: " + Build.ID + "\n");

        SimpleDateFormat sdf = new SimpleDateFormat("MMMM d, yyyy 'at' h:mm a");
        String date = sdf.format(Build.TIME);

        os_info_text.append("Build Time: " + date + "\n");
        os_info_text.append("Build Type: " + Build.TYPE + "\n");
        os_info_text.append("Build User: " + Build.USER + "\n");
        os_info_text.append("Bootloader: " + Build.BOOTLOADER + "\n");
        os_info_text.append("Kernel version: " + System.getProperty("os.version") + "\n");
    }
}