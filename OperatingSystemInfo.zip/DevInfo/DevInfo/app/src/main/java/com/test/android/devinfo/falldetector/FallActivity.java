package com.test.android.devinfo.falldetector;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.test.android.devinfo.R;

public class FallActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String TAG = "FallActivity";

    private Button btnSet;
    private Button btnStart;
    private Button btnHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fall);


        btnSet = findViewById(R.id.btn_set);
        btnSet.setOnClickListener(this);

        btnStart =  findViewById(R.id.btn_start);
        btnStart.setOnClickListener(this);

        btnHistory = findViewById(R.id.btn_history);
        btnHistory.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.btn_set:
                intent = new Intent(this, SetActivity.class);
                startActivity(intent);
                return;
            case R.id.btn_start:
                intent = new Intent(this, StartActivity.class);
                startActivity(intent);
                return;
            case R.id.btn_history:
                intent = new Intent(this, HistoryActivity.class);
                startActivity(intent);
                return;
        }
    }

}