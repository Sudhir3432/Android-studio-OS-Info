package com.test.android.devinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class DevInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dev_info);
        TextView tv=findViewById(R.id.dev_info_text);

        String arch = System.getProperty("os.arch");

        tv.append("Model: " + Build.MODEL + "\n");
        tv.append("Board: " + Build.BOARD + "\n");
        tv.append("Brand: " + Build.BRAND + "\n");
        tv.append("Manufacturer: " + Build.MANUFACTURER + "\n");
        tv.append("Device: " + Build.DEVICE + "\n");
        tv.append("Product: " + Build.PRODUCT + "\n");
        tv.append("TAGS: " + Build.TAGS + "\n");
        tv.append("Serial: " + Build.SERIAL + "\n");



        tv.append("\n" + "***** SOC *****" + "\n");
        tv.append("Hardware: " + Build.HARDWARE + "\n");
        tv.append("Number of cores: " + getNumberOfCores() + "\n");
        tv.append("Architecture: " + arch + "\n");

        tv.append("\n" + "***** CPU Info *****" + "\n");
        tv.append(ReadCPUinfo() + "\n");




    }




    private String ReadCPUinfo() {
        ProcessBuilder cmd;
        String result = "";

        try {
            String[] args = {"/system/bin/cat", "/proc/cpuinfo"};
            cmd = new ProcessBuilder(args);

            Process process = cmd.start();
            InputStream in = process.getInputStream();
            byte[] re = new byte[1024];
            while (in.read(re) != -1) {
                System.out.println(new String(re));
                result = result + new String(re);
            }
            in.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return result;
    }

    public int getNumberOfCores() {
        if (Build.VERSION.SDK_INT >= 17) {
            return Runtime.getRuntime().availableProcessors();
        } else {
            //Code for old SDK values
            return 0;
            //return Runtime.getRuntime().availableProcessors();
        }
    }
    /*
    public static String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return model;
        }
        return manufacturer + " " + model;
    }
    */
}