package com.test.android.devinfo;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;

public class MemoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memory);
      //  Toast.makeText(this, "Memory Activity", Toast.LENGTH_SHORT).show();
        TextView memory_info_text = findViewById(R.id.memory_info_text);
        memory_info_text.append(getMemoryInfo() + "\n");
    }
    public String getMemoryInfo() {
        ProcessBuilder cmd;
        String result = "";

        try {
            String[] args = {"/system/bin/cat", "/proc/meminfo"};
            cmd = new ProcessBuilder(args);

            Process process = cmd.start();
            InputStream in = process.getInputStream();
            byte[] re = new byte[1024];
            while (in.read(re) != -1) {
                System.out.println(new String(re));
                result = result + new String(re);
            }
            in.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

}