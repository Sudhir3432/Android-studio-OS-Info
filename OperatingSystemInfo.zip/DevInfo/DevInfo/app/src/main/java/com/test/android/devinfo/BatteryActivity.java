package com.test.android.devinfo;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class BatteryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battery);

        TextView battery_info_text = findViewById(R.id.battery_info_text);
        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = this.registerReceiver(null, ifilter);
        float batteryTemp = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) / 10f;

        BatteryManager batteryManager = (BatteryManager) this.getSystemService(this.BATTERY_SERVICE);
        int chargeCounter = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
        int capacity = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

        int batteryCap = (chargeCounter == Integer.MIN_VALUE || capacity == Integer.MIN_VALUE) ? 0 : (chargeCounter / capacity) / 10;

        float batteryPct = level * 100 / (float) scale;

        battery_info_text.setText("Battery Percentage : " + batteryPct + "%" + "\n");
        battery_info_text.append("Battery Temperature: " + batteryTemp + "°C" + "\n");
        battery_info_text.append("Battery Capacity : " + batteryCap + "mAh" + "\n");
    }
}