package com.test.android.devinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.google.android.material.card.MaterialCardView;
import com.test.android.devinfo.falldetector.FallActivity;

public class MainActivity extends AppCompatActivity {
    MaterialCardView card_device, card_os, card_battery, card_sensors, card_memory,
            card_network,card_gps,card_camera,card_fall;
    TextView textView,textView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView2);
        textView2 = findViewById(R.id.textView3);
        card_device = findViewById(R.id.card_device);
        card_os = findViewById(R.id.card_os);
        card_battery = findViewById(R.id.card_battery);
        card_sensors = findViewById(R.id.card_sensor);
        card_memory = findViewById(R.id.card_memory);
        card_network = findViewById(R.id.card_network);
        card_gps = findViewById(R.id.card_gps);
        card_camera = findViewById(R.id.card_camera);
        card_fall = findViewById(R.id.card_fall);
        textView.setText("v"+BuildConfig.VERSION_NAME);
        textView2.setText("©2021 SURAJ INFORMATICS. All Rights Reserved .");
        card_device.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, DevInfoActivity.class));
        });
        card_os.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, OsActivity.class));
        });
        card_battery.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, BatteryActivity.class));
        });
        card_sensors.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, SensorActivity.class));
        });
        card_memory.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, MemoryActivity.class));
        });
        card_network.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, NetworkActivity.class));
        });
        card_gps.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, GpsActivity.class));
        });
        card_camera.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, CameraActivity.class));
        });
        card_fall.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, FallActivity.class));
        });
    }
}