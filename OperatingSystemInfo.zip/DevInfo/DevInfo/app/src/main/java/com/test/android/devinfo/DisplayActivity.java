package com.test.android.devinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Locale;

public class DisplayActivity extends AppCompatActivity {
 ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        imageView = findViewById(R.id.miniImageView);
        Bitmap bitmap = BitmapFactory.decodeFile(getIntent().getStringExtra("image_path"));
        Log.d("bitmap", "bitmap: "+bitmap);
        if(bitmap != null){
            imageView.setImageBitmap(bitmap);
        }else {
            Toast.makeText(this, "Please first capture the image", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(this,CameraActivity.class);
            startActivity(i);

        }

    }
}