package com.test.android.devinfo;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class NetworkActivity extends AppCompatActivity {
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_network);
        //Toast.makeText(this, "Network Activity", Toast.LENGTH_SHORT).show();
        TextView network_info_text = findViewById(R.id.network_info_text);
        // Get System TELEPHONY service reference
        TelephonyManager tManager = (TelephonyManager) getBaseContext()
                .getSystemService(Context.TELEPHONY_SERVICE);
        ConnectivityManager connectivityManager = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivityManager.getActiveNetworkInfo() != null && connectivityManager.
                getActiveNetworkInfo().isConnected())
        {
            network_info_text.append("Network : " + "Network Connected" + "\n");
            network_info_text.append("Wifi Name : " +connectivityManager.getActiveNetworkInfo().getExtraInfo() + "\n");
        }
        else
        {
            network_info_text.append("Network : " + "Network Disconnected" + "\n");
        }
// Get carrier name (Network Operator Name)
        String carrierName = tManager.getNetworkOperatorName();
        network_info_text.append("Network Name : " + carrierName + "\n");
        String networkOperatorId = tManager.getNetworkOperator();
        network_info_text.append("Network Operator Id : " + networkOperatorId + "\n");
// Get Phone model and manufacturer name
        network_info_text.append("Modem : " + Build.getRadioVersion() + "\n");
//        String ssid   =  getCurrentSsid(context);
//        network_info_text.append("ssid : " + ssid   + "\n");
    }

    /*public static String getCurrentSsid(Context context) {
        String ssid = null;
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        if (networkInfo == null) {
            return null;
        }

        if (networkInfo.isConnected()) {
            final WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            final WifiInfo connectionInfo = wifiManager.getConnectionInfo();
            if (connectionInfo != null && !TextUtils.isEmpty(connectionInfo.getSSID())) {
                ssid = connectionInfo.getSSID();
            }
        }

        return ssid;
    }*/
}